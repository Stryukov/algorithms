# ID: 87502845

class Stack:
    def __init__(self) -> None:
        self.items = []

    def push(self, item: int) -> None:
        self.items.append(item)

    def pop(self) -> int:
        return self.items.pop()


def calculate(exp: str) -> int:
    """Вычисляет значения выражения, 
    записанного в обратной польской нотации.
    """
    stack = Stack()
    for elem in exp:
        try:
            stack.push(int(elem))
        except ValueError:
            operand2 = stack.pop()
            operand1 = stack.pop()
            if elem == '+':
                stack.push(operand1 + operand2)
            elif elem == '-':
                stack.push(operand1 - operand2)
            elif elem == '*':
                stack.push(operand1 * operand2)
            elif elem == '/':
                stack.push(operand1 // operand2)
    return stack.pop()


def main():
    exp = input().split()
    print(calculate(exp))


if __name__ == '__main__':
    main()
