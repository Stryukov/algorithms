# ID: 87501278

class SizeError(Exception):
    pass


class Deque():
    """Дек с ограниченным размером max_size"""
    def __init__(self, max_size: int) -> None:
        self.deque = [None] * max_size
        self.max_size = max_size
        self.head = 0
        self.tail = 0
        self.deque_size = 0

    def push_back(self, value: int) -> None:
        if self.deque_size != self.max_size:
            self.deque[self.tail] = value
            self.tail = (self.tail + 1) % self.max_size
            self.deque_size += 1
        else:
            raise SizeError

    def push_front(self, value: int) -> None:
        if self.deque_size != self.max_size:
            self.deque[self.head - 1] = value
            self.head = (self.head - 1) % self.max_size
            self.deque_size += 1
        else:
            raise SizeError

    def pop_front(self) -> int:
        if self.deque_size:
            value = self.deque[self.head]
            self.deque[self.head] = None
            self.head = (self.head + 1) % self.max_size
            self.deque_size -= 1
            return value
        else:
            raise SizeError

    def pop_back(self) -> int:
        if self.deque_size:
            value = self.deque[self.tail - 1]
            self.deque[self.tail - 1] = None
            self.tail = (self.tail - 1) % self.max_size
            self.deque_size -= 1
            return value
        else:
            raise SizeError


def main():
    count_cmd = int(input())
    max_size = int(input())
    deque = Deque(max_size)
    for i in range(count_cmd):
        command = input().split()
        try:
            if command[0] == 'push_back':
                deque.push_back(command[1])
            if command[0] == 'push_front':
                deque.push_front(command[1])
            if command[0] == 'pop_front':
                print(deque.pop_front())
            if command[0] == 'pop_back':
                print(deque.pop_back())
        except SizeError:
            print('error')


if __name__ == '__main__':
    main()
